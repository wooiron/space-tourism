export const colorType1 = '#0B0D17';
export const colorType2 = '#D0D6F9';
export const colorType3 = '#FFFFFF';
export const hoverColor = '#979797';
