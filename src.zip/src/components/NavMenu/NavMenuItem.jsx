import PropTypes from 'prop-types';
import Text from '../../styling/elements/Text';
import styled from 'styled-components';
import { hoverColor } from '../../constant/colors';

const NavMenuItem = ({
  number = '',
  name = '',
  focused = false,
  handleClick,
}) => {
  const onClick = () => {
    console.log('hi');
    handleClick(name);
  };
  return (
    <Body onClick={onClick} focused={focused}>
      <Text.Nav>
        {number} {name}
      </Text.Nav>
    </Body>
  );
};

NavMenuItem.propTypes = {
  number: PropTypes.string,
  name: PropTypes.string,
  focused: PropTypes.bool,
  handleClick: PropTypes.func,
};

const Body = styled.div`
  display: flex;

  align-items: center;
  justify-content: center;

  &:hover {
    cursor: pointer;
    border-bottom: 3px solid ${hoverColor};
  }
  border-bottom: ${(props) =>
    props.focused ? '3px solid #fff !important' : 'none'};
`;

export default NavMenuItem;
