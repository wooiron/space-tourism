import styled from 'styled-components';
import Text from '../../styling/elements/Text';
import { colorType2 } from '../../constant/colors';
import MainButton from './components/MainButton';
import { useState } from 'react';

const HomePage = () => {
  const handleClick = () => {};

  return (
    <Container>
      <Body>
        <LeftBody>
          <Text.H5 color={colorType2}>SO, YOU WANT TO TRAVLE TO</Text.H5>
          <Text.H1>SPACE</Text.H1>
          <TextBodyWarpper>
            <Text.Body color={colorType2}>
              Let’s face it; if you want to go to space, you might as well
              genuinely go to outer space and not hover kind of on the edge of
              it. Well sit back, and relax because we’ll give you a truly out of
              this world experience!
            </Text.Body>
          </TextBodyWarpper>
        </LeftBody>
        <RightBody>
          <MainButton text="EXPLORE" handleClick={handleClick} />
        </RightBody>
      </Body>
    </Container>
  );
};

const Container = styled.div`
  width: 100%;
`;

const Body = styled.div`
  display: flex;
  position: relative;

  width: 100%;

  margin-top: 15%;
  padding-left: 165px;
  padding-right: 165px;

  justify-content: space-between;
  align-items: center;
`;

const LeftBody = styled.div`
  flex: 1;
`;

const TextBodyWarpper = styled.div`
  width: 90%;
`;

const RightBody = styled.div`
  flex: 1;
  display: flex;
  position: relative;

  justify-content: flex-end;
  align-self: flex-end;
`;

export default HomePage;
