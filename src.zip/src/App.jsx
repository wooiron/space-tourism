import { useState } from 'react';
import logo from '/assets/shared/logo.svg';

import styled from 'styled-components';
import HomePage from './pages/Home';
import NavMenuList from './components/NavMenu/NavMenuList';

const menuList = [
  { number: '00', name: 'HOME' },
  { number: '01', name: 'DESTINATION' },
  { number: '02', name: 'CREW' },
  { number: '03', name: 'TECHNOLOGY' },
];

function App() {
  const [focusedMenu, setFocusedMenu] = useState('HOME');

  const handleClick = (menu) => {
    setFocusedMenu(menu);
  };
  return (
    <Body>
      <Header>
        <StarPoint />
        <HorizontalLine />
        <NavMenuList
          menuList={menuList}
          focusedMenu={focusedMenu}
          handleClick={handleClick}
        />
      </Header>
      <HomePage />
    </Body>
  );
}

const Body = styled.div`
  width: 100vw;
  height: 100vh;

  background: url('/assets/home/background-home-desktop.jpg') no-repeat center
    fixed;
  background-size: cover;
`;

const Header = styled.div`
  display: flex;
  position: relative;

  flex-direction: row;
  align-items: center;

  margin-left: 55px;
  height: 93px;
  top: 40px;
`;

const HorizontalLine = styled.div`
  height: 1px;

  background-color: #979797;
`;

const StarPoint = styled.img.attrs({
  src: `${logo}`,
})`
  width: 48px;
  height: 48px;
  margin-right: 64px;
`;

export default App;
