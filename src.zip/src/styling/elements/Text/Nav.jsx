import styled from 'styled-components';

const Nav = styled.nav`
  font-family: 'Barlow Condensed', sans-serif;
  font-size: 16px;
  color: #fff;
  letter-spacing: 2.7px;
`;

export default Nav;

// font-family: 'Barlow', sans-serif;
// font-family: 'Barlow Condensed', sans-serif;
// font-family: 'Bellefair', serif;
