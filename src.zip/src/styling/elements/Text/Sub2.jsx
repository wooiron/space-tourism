import styled from 'styled-components';

const Sub2 = styled.h1`
  font-family: 'Barlow Condensed', sans-serif;
  font-size: 14px;
  color: #fff;
  letter-spacing: 2.35px;
`;

export default Sub2;

// font-family: 'Barlow', sans-serif;
// font-family: 'Barlow Condensed', sans-serif;
// font-family: 'Bellefair', serif;
